import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='davidraya980',
    application_name='todo-list-serverless',
    app_uid='4TrTCCkdW6s9dQdGPT',
    org_uid='ccabb1c5-c232-418f-b2a5-1b39a335d682',
    deployment_uid='7c9e3902-1a5a-4aef-8663-1b746663f1c9',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.1.4',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
